rm magic_class.tar.gz
tar cvf magic_class.tar *
gzip magic_class.tar

