package loti.homeFront.vo;

public class PersonVO {
	String name;
	String email;
	String id;
	String seq;
	String key;
	String param1;
	String mqEtc;
	String mqSubject;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getParam1() {
		return param1;
	}
	public void setParam1(String param1) {
		this.param1 = param1;
	}
	public String getMqEtc() {
		return mqEtc;
	}
	public void setMqEtc(String mqEtc) {
		this.mqEtc = mqEtc;
	}
	public String getMqSubject() {
		return mqSubject;
	}
	public void setMqSubject(String mqSubject) {
		this.mqSubject = mqSubject;
	}
	

	
	
}
